package com.example.qrcode.activities.status

enum class FlashStatus {
    ENABLED,
    DISABLED
}